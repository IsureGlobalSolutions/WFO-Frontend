import React, { useEffect, useState, useRef } from 'react';
import './fte.css';
import { useDispatch } from 'react-redux';
import { addEditFte, getFteData, deleteFteData } from '../../redux/features/auth/authSlice';
import Stickyheader from '../upperheader/Stickyheader';
import { FaPlusSquare } from "react-icons/fa";
import { FaDeleteLeft } from "react-icons/fa6";

function FTE() {
    const dispatch = useDispatch();
    const timePickerRef = useRef(null);

    const [datalist, setdatalist] = useState([])
    const [latestfte, setlatestfte] = useState()
    // const [delete, setdelete] = useState()
    const [innerformValues, setInnerFormValues] = useState([]);
    const [innerworkingvalue, setInnerworkingvalue] = useState([]);

    const [toggle, setToggle] = useState(false);
    const [toggle1, setToggle1] = useState(false);

    const [selectedType, setSelectedType] = useState("Hours"); // Add state for selected type
    const [selectWorkingtype, setStateWorkingtypechange] = useState("Hours");
    const inputRef = useRef([]);
    const workingRef=useRef([]);
    const selectRef  = useRef([]);
    const selectWorkingRef  = useRef([]);


    const handleChange = (e, index) => {
        const values = [...innerformValues];
        values[index].value = e.target.value;
        setInnerFormValues(values);
    };
   
    const workinghandleChange = (e, index) => {
        const values = [...innerworkingvalue];
        values[index].value = e.target.value;
        setInnerworkingvalue(values);
    };

    const handleRemoveCustomField = (fieldType, index) => {
        setFormValues((prevValues) => ({
          ...prevValues,
          fte: {
            ...prevValues.fte,
            [fieldType]: prevValues.fte[fieldType].filter((_, i) => i !== index),
          },
        }));
      };
    const handleAddField = (e) => {
        e.preventDefault();
        const values = [...innerformValues];
        values.push({
            label: inputRef.current[0].value|| "label",
            type: selectRef.current[0].value || "text", // You may want to adjust this
            value: "",
        });
        setInnerFormValues(values);
        setToggle(false);
    };
    
    const handleAddWorking = (e) => {
        e.preventDefault();
        const values = [...innerworkingvalue];
        console.log(values , "value")
        values.push({
            label: workingRef.current[0].value|| "label",
            type: selectWorkingRef.current[0].value || "text", // You may want to adjust this
            value: "",
        });
        setInnerworkingvalue(values);
        setToggle(false);
    };
    const handleDocumentClick = (e) => {
        if (toggle && !e.target.closest('.dialog-box')) {
            setToggle(false);
        }
    };
    const handleWorkingClick = (e) => {
        if (toggle1 && !e.target.closest('.dialog-box')) {
            setToggle1(false);
        }
    };
    useEffect(() => {
        document.body.addEventListener('click', handleDocumentClick);

        return () => {
            document.body.removeEventListener('click', handleDocumentClick);
        };
    }, [toggle]);
    useEffect(() => {
        document.body.addEventListener('click', handleWorkingClick);

        return () => {
            document.body.removeEventListener('click', handleWorkingClick);
        };
    }, [toggle1]);

    const addBtnClick = (e) => {
        e.preventDefault();
        e.stopPropagation(); // Stop the event from propagating to the document body
        setToggle(true);
    };
    const workingbtnclick = (e) => {
        e.preventDefault();
        e.stopPropagation(); // Stop the event from propagating to the document body
        setToggle1(true);
    };
    const handleTypeChange = (e) => {
        setSelectedType(e.target.value);
      };
      const handleWorkingTypeChange = (e) => {
        setStateWorkingtypechange(e.target.value);
      };
    const handleDelete = async (id) => {
        try {
            await dispatch(deleteFteData(id));
            console.log("delete ", id)
        } catch (error) {
            console.error('Error deleting FTE:', error);
        }
        // window.location.reload();

    };
    useEffect(() => {
        dispatch(getFteData())
            .then((response) => {
                console.log(response, "getdatalist");
                setdatalist(response.payload);
                response?.payload?.map((element, i) => {
                    if (response?.payload?.length - 1 === i) {
                        setlatestfte(element);
                    }

                });
            })

    }, []

    )
    console.log(datalist, "datalist")
   

const [formValues, setFormValues] = useState({
    fte: {
        
      workingHours: 3,
      breakHours: 3,
      workingDays: 2,
      totalLeaves: 2,
      addtionalLeaves: 2,
      breakCustomFields: [],
  leavesCustomFields: [],
    }
  });
  const handleAddCustomField = (fieldType) => {
    const fieldName = document.querySelector('.inputtaglabel.ms-3').value;
    const fieldValue = document.querySelector('.inputlabel2').value;
  
    const newCustomField = {
      fieldName,
      fieldValue,
      type: document.querySelector('.inputlabel2').value, // Assuming the type is from the select element
    };
  
    setFormValues((prevValues) => ({
      ...prevValues,
      fte: {
        ...prevValues.fte,
        [fieldType]: [...prevValues.fte[fieldType], newCustomField],
      },
    }));
  };
  
  

  const handleCustomFieldChange = (fieldType, index, fieldName, fieldValue) => {
    
    setFormValues((prevValues) => ({
      ...prevValues,
      fte: {
        ...prevValues.fte,
        [fieldType]: prevValues.fte[fieldType].map((field, i) =>
          i === index ? { ...field, [fieldName]: fieldValue } : field
        ),
      },
    }));
  };

  const transformFormData = (formData) => {
    return {
      fte: {
        id: 0,
        createdDate: new Date().toISOString(),
        modifiedDate: new Date().toISOString(),
        createdBy: "string",
        modifiedBy: "string",
        cancelled: true,
        fte: 0,
        utilization: 0,
        workingHours: formData.fte.workingHours,
        breakHours: formData.fte.breakHours,
        workingDays: formData.fte.workingDays,
        totalLeaves: formData.fte.totalLeaves,
        addtionalLeaves: formData.fte.addtionalLeaves,
        label: "string",
        breakCustomFields: formData.fte.breakCustomFields.map((field) => ({
          fieldName: field.fieldName,
          fieldValue: field.fieldValue,
        })),
        leavesCustomFields: formData.fte.leavesCustomFields.map((field) => ({
            fieldName: field.fieldName,
            fieldValue: field.fieldValue,
          })),
      }
    };
  };
  
  
  const handleSubmit = () => {
    console.log("datappost");
  
    // Transform formValues before dispatching
    const transformedData = transformFormData(formValues);
  
    // Dispatch the addEditFte action with transformed data
    dispatch(addEditFte(transformedData));
  };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormValues((prevValues) => ({
            ...prevValues,
            [name]: value,
        }));
    };
    return (
        <>
            <div className='p-3 pb-1' style={{ backgroundColor: 'rgb(243, 242, 245)' }}>
                <Stickyheader />
            </div>
            <div className='ms-4 ps-2 mt-3 fte  '>Full-Time Equivalent (FTE)</div>
            <div className="card7  me-4 " style={{ backgroundColor: 'white' , border:'1px solid rgb(220, 226, 235)' , borderWidth:'1px'  ,borderStyle:'solid' , borderRadius:'5px' , marginLeft:"28px"}}>
                    <table className="table " >
                        <thead>
                            <tr>
                                <th colSpan="6" className='ms-4 ps-3  headingfte1' style={{backgroundColor: 'rgba(224, 220, 220, 0.921)'}} >
                                    Latest FTE
                                </th>
                            </tr>
                        </thead>
                    </table>

                    <table className="table table-bordered table-hover me-2" style={{ margin: '15px', width: '98%', backgroundColor: 'rgb(243, 242, 245)' }}>
                        <thead>
                            <tr>
                                {/* <th colSpan="6" style={{ backgroundColor: 'red', color: 'white' }}>
        Top Row with Red Background
      </th> */}
                            </tr>
                        </thead>
                        <tbody >
                            <tr >
                                <td   style={{ backgroundColor: 'white', border: '1px solid black', fontFamily: "'Roboto', sans-serif" , fontWeight: '600', textAlign: 'center', padding: '12px' , letterSpacing: '0.6px' , fontSize:'14px' }}> Working Hours</td>
                                <td style={{ backgroundColor: 'white', border: '1px solid black',  fontFamily: "'Roboto', sans-serif" , fontWeight: '600', textAlign: 'center', padding: '12px' , letterSpacing: '0.6px' , fontSize:'15px' }}>Breaking Hours</td>
                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px' , letterSpacing: '0.6px' , fontSize:'15px'}}>Working Days</td>
                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px', letterSpacing: '0.6px' , fontSize:'15px' }}>Total Leave Days</td>
                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px', letterSpacing: '0.6px' , fontSize:'15px' }}>Additional Leave Days</td>
                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px', letterSpacing: '0.6px' , fontSize:'15px' }}>Average Yearly Working Hours / 1 FTE</td>
                            </tr>
                            <tr >
                                {/* <td style={{ backgroundColor: 'white', border: '1px solid black', textAlign: 'center', padding: '12px' }}>{id+1}</td> */}
                                <td style={{backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '500', textAlign: 'center', padding: '12px', letterSpacing: '0.6px' , fontSize:'15px' }}>{latestfte?.workingHours}</td>
                                <td style={{backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '500', textAlign: 'center', padding: '12px', letterSpacing: '0.6px' , fontSize:'15px' }}>{latestfte?.breakHours}</td>
                                <td style={{backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '500', textAlign: 'center', padding: '12px', letterSpacing: '0.6px' , fontSize:'15px' }}>{latestfte?.workingDays}</td>
                                <td style={{backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '500', textAlign: 'center', padding: '12px', letterSpacing: '0.6px' , fontSize:'15px' }}>{latestfte?.totalLeaves}</td>
                                <td style={{backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '500', textAlign: 'center', padding: '12px', letterSpacing: '0.6px' , fontSize:'15px' }}>{latestfte?.addtionalLeaves}</td>
                                <td style={{backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '500', textAlign: 'center', padding: '12px', letterSpacing: '0.6px' , fontSize:'15px' }}>{latestfte?.averageYearlyHours}</td>
                                {/* <td style={{ backgroundColor: 'white', border: '1px solid black', textAlign: 'center', padding: '12px' }}>shsh</td> */}
                            </tr>
                        </tbody>
                    </table>

                

                {/* <div  style={{ backgroundColor: 'red', width: '100%', color: 'white', borderRadius: '10px solid ' }}>
    <div className='' >
        <span  className='textfte'> 
        Latest FTE</span>
            
            
    </div>
        
        </div> */}
            </div>
            <div className='d-flex gap-0 mt-2'>
                <div className="card6 col-lg-2 col-md-4 col-xl-2 col-sm-6"  style={{ backgroundColor: 'white' , border:'1px solid rgb(220, 226, 235)' , borderWidth:'1px'  ,borderStyle:'solid' , borderRadius:'5px'}}>
                <table className="table   ms-0 pe-0" style={{ borderRadius: '10px' , backgroundColor: 'rgba(224, 220, 220, 0.921)'}}>
                        <thead>
                            <tr>
                                <th colSpan="6 " className='ps-3 headingfte3' style={{backgroundColor: 'rgba(224, 220, 220, 0.921)'}}>
                                Working Days & Away Date Detail

                                </th>
                            </tr>
                        </thead>
                    </table>
                    <div className="table-container tablecontainer" >
                        <div className=' p-0 pe-0 pt-0 d-flex flex-column'>
                        {!toggle ? (
   <label className="ms-3  me-3 d-flex justify-content-center "  
   style={{
    paddingLeft:'7px' ,
    borderRadius: '5px',
    border: '1px solid grey',
    height: '34px',
    width: '250px',
  }}
  >
   <span className="col-9 p-0 email1 d-flex justify-content-start align-items-center " >
     Leaves Custom
   </span>
   <span className="p-0 m-0 col-3 d-flex justify-content-center align-items-center"
    style={{
        paddingLeft:'7px' ,
        borderRadius: '5px',
        
        backgroundColor:'rgb(243, 242, 245)',
        borderLeft: '1px solid grey',
        // height: '34px',
        // width: '250px',
      }}
   >
     <FaPlusSquare className="formicon" onClick={addBtnClick} />
   </span>
 </label>
  ) : (
    <div className="dialog-box">
      <input
        type="text"
        placeholder="type"
        className="inputtaglabel ms-3"
        ref={(el) => (inputRef.current[0] = el)}
      />
      <select
        ref={(el) => (selectRef.current[0] = el)}
        onChange={handleTypeChange}
        className="inputlabel2"
      >
        <option value="Hour" style={{ fontSize: '13px' }}>
          Hours
        </option>
        <option value="min" style={{ fontSize: '13px' }}>
          Minutes
        </option>
      </select>
      <button className="addbuttonfte" onClick={() => handleAddCustomField('leavesCustomFields')}>
        Add
      </button>
    </div>
  )}

  {formValues.fte.leavesCustomFields.map((field, index) => (
    <div key={index} className="field ">
 <div className='d-flex'> 
 <label
        className="labelfeil ms-4 mt-2 col-md-7 col-lg-7 col-sm-7"
        type="text"
        placeholder="Field Name"
        value={field.fieldName}
        onChange={(e) =>
          handleCustomFieldChange('leavesCustomFields', index, 'fieldName', e.target.value)
        }
      >{field.fieldName}</label>
      <div  className="p-0 mt-1 m-0 col-3 d-flex justify-content-center align-items-center">
<FaDeleteLeft className="formicon"
                onClick={() => handleRemoveCustomField('leavesCustomFields', index)}

/>
</div>
 </div>
      <input
        type={field.type}
        value={field.fieldValue}
        onChange={(e) =>
          handleCustomFieldChange('leavesCustomFields', index, 'fieldValue', e.target.value)
        }
        className="inputtag ms-4 mt-1 mb-1"
        style={{
          borderRadius: '5px',
          border: '1px solid grey',
          height: '30px',
          width: '230px',
        }}
        placeholder={`add value in ${field.type}`}
      />
     
    </div>
  ))}
                            {/* <div className='ms-4'>
                                <input
                                    type="text"
                                    id="workingHours"
                                    name="workingHours"
                                    placeholder="Working Hours"
                                    value={formValues.workingHours}
                                    onChange={handleInputChange}
                                    style={{
                                        borderRadius: '5px',
                                        border: '1px solid black',
                                        backgroundColor: 'white',
                                        // padding: '2px',
                                        width: '260px'
                                    }}
                                />
                            </div> */}
                        </div>
                        <div className=' mt-2 p-0 pe-0 pt-0 d-flex flex-column'>
                        {!toggle1 ? (
   <label className="ms-3  me-3 d-flex justify-content-center "  
   style={{
    paddingLeft:'7px' ,
    borderRadius: '5px',
    border: '1px solid grey',
    height: '34px',
    width: '250px',
  }}
  >
   <span className="col-9 p-0 email1 d-flex justify-content-start align-items-center " >
     Break  Feild
   </span>
   <span className="p-0 m-0 col-3 d-flex justify-content-center align-items-center"
    style={{
        paddingLeft:'7px' ,
        borderRadius: '5px',
        backgroundColor:'rgb(243, 242, 245)',
        borderLeft: '1px solid grey',
      }}
   >
     <FaPlusSquare className="formicon" onClick={workingbtnclick} />
   </span>
 </label>
  ) : (
    <div className="dialog-box">
      <input
        type="text"
        placeholder="type"
        className="inputtaglabel ms-3"
        ref={(el) => (inputRef.current[0] = el)}
      />
      <select
        ref={(el) => (selectRef.current[0] = el)}
        onChange={handleTypeChange}
        className="inputlabel2"
      >
        <option value="Hour" style={{ fontSize: '13px' }}>
          Hours
        </option>
        <option value="min" style={{ fontSize: '13px' }}>
          Minutes
        </option>
      </select>
      <button className="addbuttonfte" onClick={() => handleAddCustomField('leavesCustomFields')}>
        Add
      </button>
    </div>
  )}

  {formValues.fte.leavesCustomFields.map((field, index) => (
    <div key={index} className="field ">
 <div className='d-flex'> 
 <label
        className="labelfeil ms-4 mt-2 col-md-7 col-lg-7 col-sm-7"
        type="text"
        placeholder="Field Name"
        value={field.fieldName}
        onChange={(e) =>
          handleCustomFieldChange('leavesCustomFields', index, 'fieldName', e.target.value)
        }
      >{field.fieldName}</label>
      <div  className="p-0 mt-1 m-0 col-3 d-flex justify-content-center align-items-center">
<FaDeleteLeft className="formicon"
                onClick={() => handleRemoveCustomField('leavesCustomFields', index)}

/>
</div>
 </div>
      <input
        type={field.type}
        value={field.fieldValue}
        onChange={(e) =>
          handleCustomFieldChange('leavesCustomFields', index, 'fieldValue', e.target.value)
        }
        className="inputtag ms-4 mt-1 mb-1"
        style={{
          borderRadius: '5px',
          border: '1px solid grey',
          height: '30px',
          width: '230px',
        }}
        placeholder={`add value in ${field.type}`}
      />
     
    </div>
  ))}
                            {/* <div className='ms-4'>
                                <input
                                    type="text"
                                    id="workingHours"
                                    name="workingHours"
                                    placeholder="Working Hours"
                                    value={formValues.workingHours}
                                    onChange={handleInputChange}
                                    style={{
                                        borderRadius: '5px',
                                        border: '1px solid black',
                                        backgroundColor: 'white',
                                        // padding: '2px',
                                        width: '260px'
                                    }}
                                />
                            </div> */}
                        </div>
                        <div className='mt-1 d-flex flex-column'>
                            <div className='ms-3 '>
                                <input
                                    type="text"
                                    id="workingDays"
                                    name="workingDays"
                                    placeholder="Working Days"
                                    value={formValues.workingDays}
                                    onChange={handleInputChange}
                                    style={{
                                        paddingLeft:'7px' ,
                                        borderRadius: '5px',
                                        border: '1px solid grey', 
                                                                    height: '34px', 
                                                                    width:'250px',
                                                                    marginTop:'2px'
                                      }}
                                />
                            </div>
                        </div>
                        <div className='mt-1 d-flex flex-column'>
                            <div className='ms-3'>
                                <input
                                    type="text"
                                    id="totalLeaves"
                                    name="totalLeaves"
                                    placeholder="Total Leave Days"
                                    value={formValues.totalLeaves}
                                    onChange={handleInputChange}
                                    style={{
                                        borderRadius: '5px',
                                        paddingLeft:'7px' ,
                                        border: '1px solid grey', 
                                                                    height: '34px', // Adjusted height
                                                                    width:'250px',
                                                                    marginTop:'2px'

                                      }}
                                />
                            </div>
                        </div>
                        <div className='mt-1 d-flex flex-column'>
                            <div className='ms-3'>
                                <input
                                    type="text"
                                    id="addtionalLeaves"
                                    name="addtionalLeaves"
                                    placeholder="Additional Away Days"
                                    value={formValues.addtionalLeaves}
                                    onChange={handleInputChange}
                                    style={{
                                        borderRadius: '5px',
                                        paddingLeft:'7px' ,
                                        border: '1px solid grey', // Main div border color
                                                                    height: '34px', // Adjusted height
                                                                    width:'250px',
                                                                    marginTop:'2px'

                                      }}
                                />
                            </div>
                        </div>
                        <div className='mt-3 d-flex flex-column'>
                        <div className=' d-flex flex-column col-lg-4 ms-3 mb-2'>
                            <button type="button" className="submitbutton"
                                onClick={handleSubmit}>Submit</button>
                        </div>
                        </div>
                </div>
                </div>
                <div className="historycard col-lg-9 col-md-8 col-xl-9 col-sm-6 ps-0 ms-3" style={{ backgroundColor: 'white' ,  borderWidth:'1px'   , borderRadius:'5px'}}>
                    <table className="table mb-0 " style={{ borderRadius: '10px' , backgroundColor: 'rgba(224, 220, 220, 0.921)'}}>
                        <thead>
                            <tr>
                                <th colSpan="6 " className='ms-4 ps-3 headingfte2' style={{backgroundColor: 'rgba(224, 220, 220, 0.921)'}}>
                                    History
                                </th>
                            </tr>
                        </thead>
                    </table>
                    <div className="table-container tablecontainer" style={{   border:'1px solid rgb(220, 226, 235)'}}>

                        <table className="table table-hover" >
                            <tbody style={{ }}>

                                <tr className=''>
                                    <td style={{ border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center',  width:'80px',  padding: '12px' , fontSize:'13px',  }}> Sr. No.</td>
                                    <td style={{ border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px' , fontSize:'13px',  }}> Working Hours</td>
                                    <td style={{ border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px' , fontSize:'13px',  }}>Breaking Hours</td>
                                    <td style={{ border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px' , fontSize:'13px',  }}>Working Days</td>
                                    <td style={{ border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px' , fontSize:'13px',  }}>Total Leave Days</td>
                                    <td style={{ border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px' , fontSize:'13px',  }}>Additional Leave Days</td>
                                    <td style={{ border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px' , fontSize:'13px',  }}>Average Yearly Working Hours / 1 FTE</td>
                                    <td style={{ border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '12px' , fontSize:'13px',  }}>Delete</td>
                                </tr>
                                {datalist?.length > 0 ?
                                    datalist?.map((item, id) => {
                                        return (
                                            <tr key={id}>
                                                <td style={{ backgroundColor: 'white' , border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '16px', letterSpacing: '0.6px' , fontSize:'12px', }}>{item.id}</td>
                                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '16px', letterSpacing: '0.6px' , fontSize:'12px', }}>{item.workingHours}</td>
                                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '16px', letterSpacing: '0.6px' , fontSize:'12px', }}>{item.breakHours}</td>
                                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '16px', letterSpacing: '0.6px' , fontSize:'12px', }}>{item.workingDays}</td>
                                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '16px', letterSpacing: '0.6px' , fontSize:'12px', }}>{item.totalLeaves}</td>
                                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '16px', letterSpacing: '0.6px' , fontSize:'12px', }}>{item.addtionalLeaves}</td>
                                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center', padding: '16px', letterSpacing: '0.6px' , fontSize:'12px', }}>{item.averageYearlyHours}</td>
                                                <td style={{ backgroundColor: 'white', border: '1px solid black', fontfamily: 'Roboto sans-serif', fontWeight: '600', textAlign: 'center' }}>
                                                    <button type="submit" className="deletebutton pt-2" 
                                                        onClick={() => handleDelete(item.id)}>
                                                            <span className='pt-1'>Delete</span></button>
                                                </td>

                                                {/* <td style={{ backgroundColor: 'white', border: '1px solid black', textAlign: 'center', padding: '12px' }}>{item.createdDate}</td> */}
                                            </tr>
                                        )
                                    })
                                    :
                                    <div>Loading..</div>
                                }



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            

        </>
    )
}

export default FTE